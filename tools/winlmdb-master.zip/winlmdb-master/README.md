# winlmdb
Windows build for liblmdb that uses CMAKE to build the project

Liblmdb (https://github.com/LMDB/lmdb) comes with a unix make file, and Windows users just have to create the solution file, and includes the required files in order to compile it.

This repository is not about creating a new liblmdb for Windows. I cloned the liblmdb source code from https://github.com/LMDB/lmdb, and created CMAKE configuration file to build it consistently on Windows.

Usage:

1. Make sure CMAKE is installed
2. Make sure Visual Studio is installed
3. Open Build.bat to set the path to the installed visual studio
4. Update the toolset if required
5. From a command prompt, run Build.bat

Two folders are created for the build files:

1. Build32 - Visual Studio solution file for building 32-bit lmdb binaries
2. Build64 - Visual Studio solution file for building 64-bit lmdb binaries

The result of the build will be written in the following folders:

1. lmdb-shared-Debug-32-bit   - 32-bit lmdb.dll with Debug configuration
2. lmdb-shared-Debug-64-bit   - 64-bit lmdb.dll with Debug configuration
3. lmdb-shared-Release-32-bit - 32-bit lmdb.dll with Release configuration
4. lmdb-shared-Release-64-bit - 64-bit lmdb.dll with Release configuration
5. lmdb-static-Debug-32-bit   - 32-bit lmdb static library with Debug configuration
6. lmdb-static-Debug-64-bit   - 64-bit lmdb static library with Debug configuration
7. lmdb-static-Release-32-bit - 32-bit lmdb static library with Release configuration
8. lmdb-static-Release-64-bit - 64-bit lmdb static library with Release configuration
