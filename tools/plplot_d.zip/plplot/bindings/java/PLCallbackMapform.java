
package plplot.core;

public interface PLCallbackMapform
{
    public void mapform( double[] x, double[] y );
};
